﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class sound : MonoBehaviour
{
    
        public AudioSource Music;
    public AudioSource SFX;
    public AudioSource Voice;

    public float MasterVol = 1;
    public float MusicVol = 1;
    public float SFXVol = 1;
    public float VoiceVol = 1;

    public int MIndex = 0;
    public int SIndex = 0;
    public int VIndex = 0;

    public AudioClip[] MClips;
    public AudioClip[] SClips;
    public AudioClip[] VClips;

    private sound instance;

    void awake()
    {
        if (instance != null && instance != this)
        {
            Destroy(this.gameObject);
            return;
        }

        else
        {
            instance = this;
        }
    }

    public sound GetInstance()
    {
        return instance;
    }

    void start()
    {

    }

    public void MasterVolumeChange(float MasterVolume)
    {
        MasterVol = MasterVolume;
        AudioListener.volume = MasterVol;
    }

    public void MusicVolumeChange(float MusicVolume)
    {
        if (MasterVol <= 1)
        {
            MusicVol = MusicVolume;
            Music.ignoreListenerVolume = false;
            Music.volume = MusicVol;
        }

        else
        {
            MusicVol = MusicVolume;
            Music.ignoreListenerVolume = true;
            Music.volume = MusicVol;
        }
    }

    public void SFXVolumeChange(float SFXVolume)
    {
        if (MasterVol <= 1)
        {
            SFXVol = SFXVolume;
            SFX.ignoreListenerVolume = false;
            SFX.volume = SFXVol;
        }

        else
        {
            SFXVol = SFXVolume;
            SFX.ignoreListenerVolume = true;
            SFX.volume = SFXVol;
        }
    }

    public void VoiceVolumeChange(float VoiceVolume)
    {
        if (MasterVol <= 1)
        {
            VoiceVol = VoiceVolume;
            Voice.ignoreListenerVolume = false;
            Voice.volume = VoiceVol;

        }

        else
        {
            VoiceVol = VoiceVolume;
            Voice.ignoreListenerVolume = true;
            Voice.volume = VoiceVol;
        }
    }

    public void PlayMusic()
    {
        PlayMusic(MIndex);
    }

    public void PlayMusic(int useIndex)
    {
        if (Music != null && MClips != null)
        {
            if (MasterVol <= 1)
            {
                Music.clip = MClips[useIndex];
                Music.ignoreListenerVolume = false;
                Music.PlayOneShot(MClips[useIndex], MusicVol);
            }
            else
            {
                Music.clip = MClips[useIndex];
                Music.ignoreListenerVolume = true;
                Music.PlayOneShot(MClips[useIndex], MusicVol);
            }
        }
    }


}