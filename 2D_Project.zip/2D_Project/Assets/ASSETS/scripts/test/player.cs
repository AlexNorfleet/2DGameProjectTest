﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

[RequireComponent(typeof(control2d))]

public class player : MonoBehaviour
{
    float jumpHeight = 4;
    float timeJumpApex = .4f;
    float moveSpeed = 8;
    float accelerationTimeAirborne = .2f;
    float accelerationTimeGround = .1f;

    float gravity;
    float jumpVelocity;
    float velocityXSmoothing;

    float horizontalPress = 0;
    float verticalPress = 0;
    float jumpCount = 2;

   
    Vector3 velocity;

    control2d controller;

    void Start()
    {
        controller = GetComponent<control2d>();

        gravity = -(2 * jumpHeight) / Mathf.Pow(timeJumpApex,2);
        jumpVelocity = Mathf.Abs(gravity) * timeJumpApex;

    }

    void Update()
    {
        if(controller.collisions.above || controller.collisions.below)  // Stops from accumulating gravity pull
        {
            velocity.y = 0;
        }

        // Horizontal Movement
        if(Input.GetKey(KeyCode.A))
        {
            horizontalPress = -1;
        }
        else
        {
            if (Input.GetKey(KeyCode.D))
            {
                horizontalPress = 1;
            }
            else { horizontalPress = 0; }
        }
        //

        // Vertical Movement
        if (Input.GetKey(KeyCode.S))
        {
            verticalPress = -1;
        }
        else
        {
            if (Input.GetKey(KeyCode.W))
            {
                verticalPress = 1;
            }
            else { verticalPress = 0; }
        }
        //
        // Vector2 input = new Vector2(Input.GetAxisRaw("Horizontal"), Input.GetAxisRaw("Vertical"));
        Vector2 input = new Vector2(horizontalPress, verticalPress);

        if (Input.GetKeyDown(KeyCode.W) && (controller.collisions.below || jumpCount > 0))
        {
            velocity.y = jumpVelocity;
            jumpCount--;
        }

        if(controller.collisions.below)
        {
            jumpCount = 2;
        }
        float targetVelocityX = input.x * moveSpeed;
        velocity.x = Mathf.SmoothDamp(velocity.x, targetVelocityX, ref velocityXSmoothing, (controller.collisions.below)?accelerationTimeGround:accelerationTimeAirborne); // ? checks if its true then uses the line next to it
        velocity.y += gravity * Time.deltaTime;
        controller.Move(velocity * Time.deltaTime);
    }
}
