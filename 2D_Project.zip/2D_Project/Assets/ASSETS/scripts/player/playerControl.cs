﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class playerControl : MonoBehaviour {

    public float speed;
    public float maxSpeed = 30f;
    public bool facingRight = true;
    public float jumpCount;
    public bool jump = false;
    public float jumpForce;
    public float currentVelocity = 0;
    public float moveForce = 365f;

    private float jumpCountVal;
    public Rigidbody2D rb;

    public Transform groundCheck;
    public Transform touchCheck;
    public LayerMask groundLayer;
    public LayerMask enemyLayer;
    public bool onGround = false;
    public bool ifTouching = false;
    public bool boing = false;
    public bool dead = false;
    public float radiusGC;

    private Animator anim;
    public AudioClip[] jumpClips;
    public AudioSource[] sounds;

    public Text textDis;
    public Text velocityDis;

    void Start()
    {
       // groundCheck = transform.Find("groundCheck");
        anim = GetComponent<Animator>();
        rb = GetComponent<Rigidbody2D>();

    }

    void Update()
    {
        // The player is grounded if a linecast to the groundcheck position hits anything on the ground layer.
        //   onGround = Physics2D.Linecast(transform.position, groundCheck.position, 1 << LayerMask.NameToLayer("ground"));
        checkOnGround();
        checkIfTouch();
    }

    // Update is called once per frame
    void FixedUpdate() {
        float horizontalMove = Input.GetAxis("Horizontal");

        if (Input.GetButtonDown("Jump"))
        {
           // setText("JUMPED: " + jumpCountVal++);
            jump = true;
            ifTouching = false;
            // Jump();
        }
        setText1(rb.velocity);
        setText("On Ground: " + onGround + " 12Touching enemy: " +ifTouching+ " 2");


        gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(horizontalMove * speed, gameObject.GetComponent<Rigidbody2D>().velocity.y);
       
      
        // If the input is moving the player right and the player is facing left...
        if (horizontalMove > 0 && !facingRight)
            // ... flip the player.
            Flip();
        // Otherwise if the input is moving the player left and the player is facing right...
        else if (horizontalMove < 0 && facingRight)
            // ... flip the player.
            Flip();

    }
    
    void Jump()
    {
        // If the player should jump...
        // Add a vertical force to the player.


       GetComponent<Rigidbody2D>().velocity = Vector2.up * jumpForce;
        
        // Make sure the player can't jump again until the jump conditions from Update are satisfied.
        jump = false;
    }
    

    void Flip()
    {
        // Switch the way the player is labelled as facing.
        facingRight = !facingRight;

        // Multiply the player's x local scale by -1.
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }

    void checkOnGround()
    {
        Vector2 position = groundCheck.transform.position;
        Vector2 direction = Vector2.down;
        float distance = .5f;

        onGround = Physics2D.OverlapCircle(groundCheck.position, radiusGC, groundLayer);
    }

    void checkIfTouch()
    {
        Vector2 position = touchCheck.transform.position;
        Vector2 direction = Vector2.down;
        float distance = .2f;

        ifTouching = Physics2D.OverlapCircle(touchCheck.position, radiusGC, enemyLayer);
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pick Up"))
        {
            other.gameObject.SetActive(false);
        }
    }

    void OnTriggerEnter2D(Collider2D b)
    {
        if(b.gameObject.name == "ground")
        {
            onGround = true;
        }
        else { onGround = false; }
    }

    void OnCollisionEnter2D(Collision2D b)
    {
        if (b.gameObject.tag == "Enemy")
        {
            dead = true;
        }

        if (b.gameObject.tag == "trampoline")
        {
            boing = true;
        }
        else { boing = false; }
    }

 

    void setText(object t)
    {
        textDis.text = t.ToString() ;
    }
    void setText1(object t)
    {
        velocityDis.text = "Velocity: " + t.ToString();
    }

    void playSound(int n)
    {
        AudioSource audio = GetComponent<AudioSource>();
       // audio.audio = sounds[n];
        audio.Play();
    }

}
