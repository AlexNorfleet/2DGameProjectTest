﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(AudioSource))]
public class playerJumpMethod : MonoBehaviour
{
    [Range(1, 30)]
    public float jumpForce;
    public AudioClip jump;
    public AudioClip[] jumpSnds;
    public Transform playerT;
    public playerControl b;

    private AudioSource snd;
    private float volLowRange = .5f;
    private float volHighRange = 1.0f;
    private float jumpCnt;

    // Update is called once per frame

    void Awake()
    {
        snd = gameObject.GetComponent<AudioSource>();
        b = GetComponent<playerControl>();
        playerT = GameObject.Find("playerChar").transform;
    }

    void Update()
    {

        if (b.boing)
        {
            GetComponent<Rigidbody2D>().velocity = Vector2.up * jumpForce * 2;
            jump = jumpSnds[Random.Range(0, jumpSnds.Length)];
            snd.clip = jump;
            snd.PlayOneShot(jump, (volLowRange + volHighRange)/2);
            b.boing = false;
        }
      /*  else
        {
            if ((Input.GetButtonDown("Jump") && jumpCnt >= 0))
            {
                GetComponent<Rigidbody2D>().velocity = Vector2.up * jumpForce;
                jump = jumpSnds[Random.Range(0, jumpSnds.Length)];
                snd.clip = jump;
                snd.PlayOneShot(jump, (volLowRange + volHighRange) / 1);
                jumpCnt++;
            }
        }
        */
    }
}

