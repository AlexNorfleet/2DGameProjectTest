﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GamePlay : MonoBehaviour
{ 
    public Transform playerT;
    public playerControl b;
    public AudioClip lose;
    private AudioSource snd;
    private float volLowRange = .5f;
    private float volHighRange = 1.0f;
    // Update is called once per frame

    void Awake()
    {
        snd = gameObject.GetComponent<AudioSource>();
        b = GetComponent<playerControl>();
        playerT = GameObject.Find("playerChar").transform;
    }

    void Update()
    {

        if (!b.dead)
        {
           //
        }
        else
        {
            snd.PlayOneShot(lose, (volLowRange + volHighRange) / 2);
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
    }
}
