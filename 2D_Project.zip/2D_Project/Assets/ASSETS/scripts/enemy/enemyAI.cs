﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Collections;

public class enemyAI: MonoBehaviour {
    public float speed;
    public float maxSpeed = 30f;
    public bool facingRight = true;
    public float jumpCount;
    public bool jump = false;
    public float jumpForce;
    GameObject player;
    bool playerNear;
    public Transform playerT;
    public float movSpd;
    public bool fact;

    public float currentVelocity = 0;
    public float moveForce = 365f;
    public float horizontalMove;

    private float jumpCountVal;
    public Rigidbody2D rb;

    public Transform groundCheck;
    public Transform touchCheck;
    public LayerMask groundLayer;
    public LayerMask enemyLayer;
    public bool onGround = false;
    public bool ifTouching = false;
    public bool boing = false;
    public bool dead = false;

    // Use this for initialization
    void Start () {
       playerT = GameObject.Find("playerChar").transform;
        rb = GetComponent<Rigidbody2D>();
    }
	
	// Update is called once per frame
	void FixedUpdate () {
        float horizontalMove = 20f;

        gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(horizontalMove * speed, gameObject.GetComponent<Rigidbody2D>().velocity.y);
        if (boing)
        {
            GetComponent<Rigidbody2D>().velocity = Vector2.up * jumpForce;
            boing = false;
        }
        seekOut();

        if (horizontalMove > 0 && !facingRight)
            // ... flip the player.
            Flip();
        // Otherwise if the input is moving the player left and the player is facing right...
        else if (horizontalMove < 0 && facingRight)
            // ... flip the player.
            Flip();


    }

    void Flip()
    {
        // Switch the way the player is labelled as facing.
        facingRight = !facingRight;

        // Multiply the player's x local scale by -1.
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }

    void OnCollisionEnter2D(Collision2D b)
    {

        if (rb.gameObject.tag == "trampoline")
        {
            boing = true;
        }
        else { boing = false; }
    }


    void seekOut()
    {
        gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2(horizontalMove * speed, gameObject.GetComponent<Rigidbody2D>().velocity.y);
    }
}
